package gvclib.item.gunbase;

public interface IGun_Sword {

}
