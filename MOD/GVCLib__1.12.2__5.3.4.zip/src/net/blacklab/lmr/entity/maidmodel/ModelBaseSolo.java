package net.blacklab.lmr.entity.maidmodel;

import net.blacklab.lmr.entity.maidmodel.ModelBaseNihil;
import net.blacklab.lmr.entity.maidmodel.ModelMultiBase;
import net.minecraft.client.renderer.entity.RenderLivingBase;

public class ModelBaseSolo extends ModelBaseNihil
{

	public ModelMultiBase model;
	public ModelBaseSolo(RenderLivingBase pRender) {
		//rendererLivingEntity = pRender;
	}
	
}
