package gvclib.event;

import gvclib.mod_GVCLib;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.entity.living.EntityVehicleBase;
import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class GVCEventsRiddingVehicle_Update {
	@SubscribeEvent
	public void onRiddingMountEvent(LivingUpdateEvent event) {
		Entity target = event.getEntityLiving();
		//Entity ride = event.getEntityBeingMounted();
		if (target != null && target instanceof EntityPlayer) 
		{
			EntityPlayer player = (EntityPlayer) target;
			if (player.getRidingEntity() instanceof EntityVehicleBase && player.getRidingEntity() != null) {// 1
				EntityVehicleBase vehicle = (EntityVehicleBase) player.getRidingEntity();
				if (vehicle.night_vision) 
				{
					if (vehicle.getBoosttime() == 1) 
					{
						//if (!player.isPotionActive(MobEffects.NIGHT_VISION))
							player.addPotionEffect(
									new PotionEffect(MobEffects.NIGHT_VISION, 401, 1, false, false));
					}else {
						if (player.isPotionActive(MobEffects.NIGHT_VISION) && player.getActivePotionEffect(MobEffects.NIGHT_VISION).getDuration() < 400) {
							player.removeActivePotionEffect(MobEffects.NIGHT_VISION);
						}
					}
				}
			}
		}
	}
}